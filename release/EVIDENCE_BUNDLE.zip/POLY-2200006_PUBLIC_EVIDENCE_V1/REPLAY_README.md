# Replay the public evidence bundle

This archive is a deterministic, sanitized evidence subset. It contains no raw
chat transcript, private receipt, local path, credential, screenshot, or
third-party source PDF. After extraction, change into
`POLY-2200006_PUBLIC_EVIDENCE_V1` and run:

```bash
shasum -a 256 -c BUNDLE_SHA256SUMS.txt
python3 checks/verify_k2_l10.py
python3 checks/verify_even_family_counts.py
```

The checksum command verifies the exact archived bytes. The two dependency-free
scripts replay exact integer counts and are corroborating evidence; they do not
replace the symbolic proof, peer review, or proof-assistant verification.
