# Public evidence bundle manifest

Bundle ID: `POLY-2200006_PUBLIC_EVIDENCE_V1`.

Every archived member is a regular file with a fixed ZIP timestamp and
mode. `BUNDLE_SHA256SUMS.txt` hashes every member except itself.

## Members

- `AI_DISCLOSURE.md`
- `BUNDLE_MANIFEST.md`
- `BUNDLE_SHA256SUMS.txt`
- `CITATION.cff`
- `CLAIMS_EVIDENCE_MATRIX.md`
- `LICENSE_STATUS.md`
- `PROBLEM_AND_PROOF.md`
- `PROVENANCE.md`
- `README.md`
- `REPLAY_README.md`
- `REPRODUCIBILITY.md`
- `SECURITY.md`
- `STATUS.md`
- `audits/README.md`
- `audits/public_safe_reports/LITERATURE_PRIORITY_AUDIT.md`
- `audits/public_safe_reports/MATHEMATICAL_AUDIT.md`
- `audits/public_safe_reports/PRIORITY_AUDIT_ARCHITECTURE_2026-08-09.md`
- `checks/verify_even_family_counts.py`
- `checks/verify_k2_l10.py`
- `evidence/PRIVACY_AND_SECRET_SCAN.md`
- `evidence/README.md`
- `evidence/RELEASE_HARDENING_AUDIT_2026-08-09.md`
- `formalization/FORMALIZATION_FEASIBILITY_AND_DEPENDENCIES.md`
- `formalization/README.md`
- `formalization/aristotle/DEPENDENCY_MAP.md`
- `formalization/aristotle/REQUEST.md`
- `formalization/lean/README.md`
- `paper/BUILD.md`
- `paper/BUILD_LOG.txt`
- `paper/BUILD_STATUS.md`
- `paper/CLAIM_SCOPE_AND_LIMITATIONS.md`
- `paper/HOSTILE_MANUSCRIPT_AUDIT_PROMPT.md`
- `paper/PDF_PREFLIGHT.md`
- `paper/README.md`
- `paper/SOURCE_COMPARISON.md`
- `paper/SOURCE_QA.md`
- `paper/VERIFIER_REPLAY_LOG.txt`
- `paper/manuscript.pdf`
- `paper/manuscript.tex`
- `paper/references.bib`
- `proof/PROBLEM_AND_PROOF.md`
- `release/README.md`
- `release/RELEASE_CHECKLIST.md`
- `release/RELEASE_NOTES_v1.0.0.md`
- `verification/README.md`
